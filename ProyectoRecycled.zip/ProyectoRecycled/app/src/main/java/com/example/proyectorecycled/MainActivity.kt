package com.example.proyectorecycled

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val personList = generatePersonList()
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        val personAdapter = PersonAdapter(personList)
        recyclerView.adapter = personAdapter
    }

    private fun generatePersonList(): List<Person> {
        return listOf(
            Person("Alberto", "Ruiz", 40),
            Person("Juan", "Perez", 28),
            Person("Eva", "Garcia", 15),
            Person("Alberto", "", 37),
            Person("Laura", "", 75),
            Person("Cristina", "", 33),
            Person("Isabel", "", 87),
            Person("Pedro", "Moreno", 44),
            Person("Jose", "Android", 22),
            Person("Manuel", "Oracle", 19),
            Person("Diana", "Hibernate", 56),
        )
    }
}