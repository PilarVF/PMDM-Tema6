package com.example.proyectorecycledreto

data class Trabajo(val name: String, val especialidades: List<Especialidad>)