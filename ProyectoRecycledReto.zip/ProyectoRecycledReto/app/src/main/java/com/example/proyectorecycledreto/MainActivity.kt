package com.example.proyectorecycledreto

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.appcompat.app.AlertDialog

val trabajos = listOf(Trabajo("Programación", listOf(Especialidad("Programador de Android"),
        Especialidad("Gestor de BBDD"), Especialidad("Programador en Java"))),
    Trabajo("Diseño web", listOf(Especialidad("Especialista en Wordpress"),
        Especialidad("Técnico en JavaScript"), Especialidad("Especialista en PHP"))),
    Trabajo("Marketing digital", listOf(Especialidad("Especialista en SEO"),
        Especialidad("Técnico en SEM"), Especialidad("Especialista en Redes Sociales"))),
)

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerViewTrabajos: RecyclerView = findViewById(R.id.recyclerViewTrabajos)
        recyclerViewTrabajos.layoutManager = LinearLayoutManager(this)
        recyclerViewTrabajos.adapter = TrabajoAdapter(trabajos) { trabajo ->
            showSubjectsDialog(trabajo)
        }
    }

    private fun showSubjectsDialog(trabajo: Trabajo) {
        val subjects = trabajo.especialidades.map { it.name }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Especialidades de ${trabajo.name}")
            .setItems(subjects) { _, _ ->
                // Acción al hacer clic en una especialidad (puedes implementar algo aquí).
            }
            .setPositiveButton("Aceptar") { dialog, _ ->
                dialog.dismiss()
            }
            .create()
            .show()
    }
}