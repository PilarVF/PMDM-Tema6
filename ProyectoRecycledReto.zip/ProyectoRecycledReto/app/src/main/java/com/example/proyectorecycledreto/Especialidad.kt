package com.example.proyectorecycledreto

data class Especialidad(val name: String)