package com.example.proyectorecycled2

data class Alumno(val nombre: String, val apellido: String, val curso: String,
                  val asignatura: String, val nota: Double)