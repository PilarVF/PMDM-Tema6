package com.example.proyectorecycled2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val alumnoList = generateAlumnoList()
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        val alumnoAdapter = AlumnoAdapter(alumnoList)
        recyclerView.adapter = alumnoAdapter
    }

    private fun generateAlumnoList(): List<Alumno> {
        return listOf(
            Alumno("Antonio", "Gomez", "1ºDAM", "Programacion", 7.5),
            Alumno("Juan", "Perez", "1ºDAW", "Bases de Datos", 5.0),
            Alumno("Eva", "Garcia", "2ºDAM", "Acceso de Datos", 10.0),
            Alumno("Alberto", "Luque", "1ºDAM", "Lenguajes de Marcas", 4.5),
            Alumno("Laura", "Martinez", "2ºDAM", "PMDM", 8.0),
            Alumno("Cristina", "Lopez", "1ºDAW", "Entornos de Desarollo", 6.5),
            Alumno("Isabel", "Fernandez", "1ºDAM", "FOL", 9.5),
            Alumno("Pedro", "Moreno", "2ºDAM", "Desarrollo de Interfaces", 7.0),
            Alumno("Jose", "Campos", "2ºDAM", "SGE", 9.0),
            Alumno("Manuel", "Romero", "1ºDAW", "Sistemas Informaticos", 8.5),
        )
    }
}