package com.example.ejercicioavanzado

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText

class CalculadoraActivity : AppCompatActivity() {
    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora)

        val btnSumar = findViewById<AppCompatButton>(R.id.btnSumar)
        val btnRestar = findViewById<AppCompatButton>(R.id.btnRestar)
        val btnMultiplicar = findViewById<AppCompatButton>(R.id.btnMultiplicar)
        val btnDividir = findViewById<AppCompatButton>(R.id.btnDividir)
        val edOp1 = findViewById<AppCompatEditText>(R.id.edOp1)
        val edOp2 = findViewById<AppCompatEditText>(R.id.edOp2)

        btnSumar.setOnClickListener { realizarOperacion("sumar", edOp1, edOp2) }
        btnRestar.setOnClickListener { realizarOperacion("restar", edOp1, edOp2) }
        btnMultiplicar.setOnClickListener { realizarOperacion("multiplicar", edOp1, edOp2) }
        btnDividir.setOnClickListener { realizarOperacion("dividir", edOp1, edOp2) }
    }

    private fun realizarOperacion(operacion: String, edOp1: AppCompatEditText, edOp2: AppCompatEditText) {
        val op1String = edOp1.text.toString()
        val op2String = edOp2.text.toString()

        if (op1String.isNotEmpty() && op2String.isNotEmpty()) {
            try {
                val op1 = op1String.toInt()
                val op2 = op2String.toInt()

                val intent = Intent(this, ResultadoActivity::class.java)
                intent.putExtra("OPERACION", operacion)
                intent.putExtra("OPERADOR1", op1)
                intent.putExtra("OPERADOR2", op2)

                startActivity(intent)

            } catch (e: NumberFormatException) {
                e.printStackTrace()
            }
        }
    }
}