package com.example.ejercicioavanzado

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class ResultadoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)

        val tvResultado = findViewById<TextView>(R.id.tvResultado)
        val operacion = intent.getStringExtra("OPERACION")
        val op1 = intent.getIntExtra("OPERADOR1", 0).toFloat()
        val op2 = intent.getIntExtra("OPERADOR2", 0).toFloat()

        val resultado = when (operacion) {
            "sumar" -> op1 + op2
            "restar" -> op1 - op2
            "multiplicar" -> op1 * op2
            "dividir" -> if (op2 != 0f) op1 / op2 else Float.NaN // Para manejar la división por cero.
            else -> Float.NaN // Para manejar operación desconocida.
        }

        val resultadoText = if (!resultado.isNaN()) {
            "Resultado: $resultado"
        } else {
            "Error al realizar la operación."
        }

        tvResultado.text = resultadoText
    }
}