package com.example.ciclodevida2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View

class ActivityB : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_b)
        Log.d("Lifecycle", "ActivityB - onCreate")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Lifecycle", "ActivityB - onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Lifecycle", "ActivityB - onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Lifecycle", "ActivityB - onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Lifecycle", "ActivityB - onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Lifecycle", "ActivityB - onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Lifecycle", "ActivityB - onDestroy")
    }

    fun goBackToActivityA(view: View) {
        finish()
    }
}