package com.example.ciclodevida2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class ActivityA : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_a)
        Log.d("Lifecycle", "ActivityA - onCreate")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Lifecycle", "ActivityA - onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Lifecycle", "ActivityA - onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Lifecycle", "ActivityA - onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Lifecycle", "ActivityA - onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Lifecycle", "ActivityA - onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Lifecycle", "ActivityA - onDestroy")
    }

    fun goToActivityB(view: View) {
        val intent = Intent(this, ActivityB::class.java)
        startActivity(intent)
    }
}