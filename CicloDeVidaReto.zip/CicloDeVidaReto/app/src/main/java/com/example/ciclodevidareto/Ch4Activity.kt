package com.example.ciclodevidareto

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View

class Ch4Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ch4)
        Log.d("Lifecycle", "Ch4Activity - onCreate")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Lifecycle", "Ch4Activity - onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Lifecycle", "Ch4Activity - onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Lifecycle", "Ch4Activity - onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Lifecycle", "Ch4Activity - onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Lifecycle", "Ch4Activity - onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Lifecycle", "Ch4Activity - onDestroy")
    }

    fun goBackToCh3(view: View) {
        finish()
    }

    fun exit(view: View) {
        finishAffinity()
    }
}