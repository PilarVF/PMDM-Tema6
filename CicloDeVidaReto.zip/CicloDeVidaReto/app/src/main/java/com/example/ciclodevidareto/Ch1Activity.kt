package com.example.ciclodevidareto

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View

class Ch1Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ch1)
        Log.d("Lifecycle", "Ch1Activity - onCreate")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Lifecycle", "Ch1Activity - onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Lifecycle", "Ch1Activity - onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Lifecycle", "Ch1Activity - onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Lifecycle", "Ch1Activity - onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Lifecycle", "Ch1Activity - onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Lifecycle", "Ch1Activity - onDestroy")
    }

    fun goToCh2(view: View) {
        val intent = Intent(this, Ch2Activity::class.java)
        startActivity(intent)
    }
}