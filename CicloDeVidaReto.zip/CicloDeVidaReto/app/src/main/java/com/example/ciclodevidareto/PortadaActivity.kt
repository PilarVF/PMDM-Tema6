package com.example.ciclodevidareto

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View

class PortadaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_portada)
        Log.d("Lifecycle", "PortadaActivity - onCreate")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Lifecycle", "PortadaActivity - onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Lifecycle", "PortadaActivity - onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Lifecycle", "PortadaActivity - onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Lifecycle", "PortadaActivity - onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Lifecycle", "PortadaActivity - onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Lifecycle", "PortadaActivity - onDestroy")
    }

    fun goToCh1(view: View) {
        val intent = Intent(this, Ch1Activity::class.java)
        startActivity(intent)
    }
}