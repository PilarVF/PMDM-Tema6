package com.example.ciclodevida3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View

class ActivityC : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_c)
        Log.d("Lifecycle", "ActivityC - onCreate")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Lifecycle", "ActivityC - onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Lifecycle", "ActivityC - onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Lifecycle", "ActivityC - onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Lifecycle", "ActivityC - onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Lifecycle", "ActivityC - onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Lifecycle", "ActivityC - onDestroy")
    }

    fun goToActivityD(view: View) {
        val intent = Intent(this, ActivityD::class.java)
        startActivity(intent)
    }
}