package com.example.ciclodevida3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class ActivityD : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_d)
        Log.d("Lifecycle", "ActivityD - onCreate")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Lifecycle", "ActivityD - onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Lifecycle", "ActivityD - onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Lifecycle", "ActivityD - onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Lifecycle", "ActivityD - onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Lifecycle", "ActivityD - onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Lifecycle", "ActivityD - onDestroy")
    }

    fun finishApp(view: android.view.View) {
        finishAffinity()
    }
}