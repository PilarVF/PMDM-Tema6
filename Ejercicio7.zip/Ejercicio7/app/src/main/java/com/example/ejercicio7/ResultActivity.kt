package com.example.ejercicio7

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        val tvResult=findViewById<TextView>(R.id.tvResult)
        val name: String = intent.extras?.getString("EXTRA_NAME").orEmpty()
        val surnames: String = intent.extras?.getString("EXTRA_SURNAMES").orEmpty()
        val course: String = intent.extras?.getString("EXTRA_COURSE").orEmpty()
        val subject: String = intent.extras?.getString("EXTRA_SUBJECT").orEmpty()
        val grade: String = intent.extras?.getString("EXTRA_GRADE").orEmpty()
        tvResult.text = "Hola $name" +
                "\n" +
                "\nDetalles: " +
                "\nApellidos: $surnames" +
                "\nCurso: $course" +
                "\nAsignatura: $subject" +
                "\nNota: $grade"
    }
}