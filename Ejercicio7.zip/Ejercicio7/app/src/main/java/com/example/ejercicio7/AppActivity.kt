package com.example.ejercicio7

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.widget.AppCompatButton

class AppActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app)
        val btnStart = findViewById<AppCompatButton>(R.id.btnStart)
        val nombre = findViewById<EditText>(R.id.nombre)
        val apellidos = findViewById<EditText>(R.id.apellidos)
        val curso = findViewById<EditText>(R.id.curso)
        val asigatura = findViewById<EditText>(R.id.asignatura)
        val nota = findViewById<EditText>(R.id.nota)

        btnStart.setOnClickListener {
            val name = nombre.text.toString()
            val surnames = apellidos.text.toString()
            val course = curso.text.toString()
            val subject = asigatura.text.toString()
            val grade = nota.text.toString()

            if (name.isNotEmpty() && surnames.isNotEmpty() && course.isNotEmpty()
                && subject.isNotEmpty() && grade.isNotEmpty()) {
                val intent = Intent(this, ResultActivity::class.java)
                intent.putExtra("EXTRA_NAME", name)
                intent.putExtra("EXTRA_SURNAMES", surnames)
                intent.putExtra("EXTRA_COURSE", course)
                intent.putExtra("EXTRA_SUBJECT", subject)
                intent.putExtra("EXTRA_GRADE", grade)
                startActivity(intent)
            }
        }
        // Al arrancar la pantalla
    }
}