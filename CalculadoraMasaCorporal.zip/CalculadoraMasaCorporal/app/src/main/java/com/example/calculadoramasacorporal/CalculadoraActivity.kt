package com.example.calculadoramasacorporal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.slider.RangeSlider
import java.text.DecimalFormat

class CalculadoraActivity : AppCompatActivity() {
    private var esHombreSelected: Boolean = true
    private var esMujerSelected: Boolean = false
    private var pesoActual: Int = 0
    private var edadActual: Int = 0
    private var alturaActual: Int = 0

    private lateinit var cardView1: CardView
    private lateinit var cardView2: CardView
    private lateinit var tvAltura: TextView
    private lateinit var rsAltura: RangeSlider
    private lateinit var btnMenos1: FloatingActionButton
    private lateinit var btnMas1: FloatingActionButton
    private lateinit var tvPeso: TextView
    private lateinit var btnMenos2: FloatingActionButton
    private lateinit var btnMas2: FloatingActionButton
    private lateinit var tvEdad: TextView
    private lateinit var btnCalcular: Button

    companion object {
        const val IMC_KEY = "IMC_RESULTADO"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora)
        initComponents()
        initListeners()
        initUI()
    }

    private fun initComponents() {
        cardView1 = findViewById(R.id.cardView1)
        cardView2 = findViewById(R.id.cardView2)
        tvAltura = findViewById(R.id.tvAltura)
        rsAltura = findViewById(R.id.rsAltura)
        btnMenos1 = findViewById(R.id.btnMenos1)
        btnMas1 = findViewById(R.id.btnMas1)
        tvPeso = findViewById(R.id.tvPeso)
        btnMenos2 = findViewById(R.id.btnMenos2)
        btnMas2 = findViewById(R.id.btnMas2)
        tvEdad = findViewById(R.id.tvEdad)
        btnCalcular = findViewById(R.id.btnCalcular)
    }

    private fun initListeners() {
        cardView1.setOnClickListener {
            changeGender()
            setGenderColor()
        }

        cardView2.setOnClickListener {
            changeGender()
            setGenderColor()
        }

        rsAltura.addOnChangeListener { _, value, _ ->
            val df = DecimalFormat("#.##")
            alturaActual = df.format(value).toInt()
            tvAltura.text = "$alturaActual cm"
        }

        btnMas1.setOnClickListener {
            pesoActual += 1
            setWeight()
        }

        btnMenos1.setOnClickListener {
            pesoActual -= 1
            setWeight()
        }

        btnMas2.setOnClickListener {
            edadActual += 1
            setAge()
        }

        btnMenos2.setOnClickListener {
            edadActual -= 1
            setAge()
        }

        btnCalcular.setOnClickListener {
            val result = calculateIMC()
            navigateToResult(result)
        }
    }

    private fun navigateToResult(result: Double) {
        val intent = Intent(this, ResultadoActivity::class.java)
        intent.putExtra(IMC_KEY, result)
        startActivity(intent)
    }

    private fun calculateIMC():Double {
        val df = DecimalFormat("#.##")
        val imc = pesoActual / (alturaActual.toDouble() /100 * alturaActual.toDouble()/100)
        return df.format(imc).toDouble()
    }

    private fun setAge() {
        tvEdad.text = edadActual.toString()
    }

    private fun setWeight() {
        tvPeso.text = pesoActual.toString()
    }

    private fun changeGender() {
        esHombreSelected = !esHombreSelected
        esMujerSelected = !esMujerSelected
    }

    private fun setGenderColor() {
        cardView1.setCardBackgroundColor(getBackgroundColor(esHombreSelected))
        cardView2.setCardBackgroundColor(getBackgroundColor(esMujerSelected))
    }

    private fun getBackgroundColor(isSelectedComponent: Boolean): Int {
        val colorReference = if (isSelectedComponent) {
            R.color.background_component_selected

        } else {
            R.color.background_component
        }

        return ContextCompat.getColor(this, colorReference)
    }

    private fun initUI() {
        setGenderColor()
        setWeight()
        setAge()
    }
}