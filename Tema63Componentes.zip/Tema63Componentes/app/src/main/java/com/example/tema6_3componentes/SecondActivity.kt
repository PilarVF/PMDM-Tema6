package com.example.tema6_3componentes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val ingresos = intent.getIntExtra("ingresos", 0)
        val edad = intent.getIntExtra("edad", 0)
        val opcionSeleccionada = intent.getStringExtra("opcionSeleccionada") ?: ""

        val tvResultado = findViewById<TextView>(R.id.tvResultado)
        tvResultado.text = "Ingresos: $ingresos al mes, Edad: $edad años, Opción $opcionSeleccionada"
    }
}