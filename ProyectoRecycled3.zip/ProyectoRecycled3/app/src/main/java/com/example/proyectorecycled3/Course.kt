package com.example.proyectorecycled3

data class Course(val name: String, val subjects: List<Subject>)