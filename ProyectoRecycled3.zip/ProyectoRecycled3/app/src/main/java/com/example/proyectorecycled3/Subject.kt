package com.example.proyectorecycled3

data class Subject(val name: String)