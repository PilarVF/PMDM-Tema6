package com.example.retocalculadora

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CalculadoraActivity : AppCompatActivity(), View.OnClickListener {
    private var operador: String? = null
    private var valorAnterior: String ? = null

    private var textView: TextView?= null

    private var btn0: Button?=null
    private var btn1: Button?=null
    private var btn2: Button?=null
    private var btn3: Button?=null
    private var btn4: Button?=null
    private var btn5: Button?=null
    private var btn6: Button?=null
    private var btn7: Button?=null
    private var btn8: Button?=null
    private var btn9: Button?=null
    private var btnPunto: Button?=null
    private var btnSum: Button?=null
    private var btnRes: Button?=null
    private var btnMult: Button?=null
    private var btnDiv: Button?=null
    private var btnIgual : Button?=null
    private var btnDel: Button?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora)

        textView = findViewById(R.id.textView)

        btn0=findViewById<Button>(R.id.btn0)
        btn1=findViewById<Button>(R.id.btn1)
        btn2=findViewById<Button>(R.id.btn2)
        btn3=findViewById<Button>(R.id.btn3)
        btn4=findViewById<Button>(R.id.btn4)
        btn5=findViewById<Button>(R.id.btn5)
        btn6=findViewById<Button>(R.id.btn6)
        btn7=findViewById<Button>(R.id.btn7)
        btn8=findViewById<Button>(R.id.btn8)
        btn9=findViewById<Button>(R.id.btn9)
        btnPunto=findViewById<Button>(R.id.btnPunto)
        btnSum=findViewById<Button>(R.id.btnSum)
        btnRes=findViewById<Button>(R.id.btnRes)
        btnMult=findViewById<Button>(R.id.btnMult)
        btnDiv=findViewById<Button>(R.id.btnDiv)
        btnIgual=findViewById<Button>(R.id.btnIgual)
        btnDel=findViewById<Button>(R.id.btnDel)

        btn0!!.setOnClickListener(this)
        btn1!!.setOnClickListener(this)
        btn2!!.setOnClickListener(this)
        btn3!!.setOnClickListener(this)
        btn4!!.setOnClickListener(this)
        btn5!!.setOnClickListener(this)
        btn6!!.setOnClickListener(this)
        btn7!!.setOnClickListener(this)
        btn8!!.setOnClickListener(this)
        btn9!!.setOnClickListener(this)
        btnPunto!!.setOnClickListener(this)
        btnSum!!.setOnClickListener(this)
        btnRes!!.setOnClickListener(this)
        btnMult!!.setOnClickListener(this)
        btnDiv!!.setOnClickListener(this)
        btnIgual!!.setOnClickListener(this)
        btnDel!!.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        var resultado: Float = 0f

        when (v?.id) {
            R.id.btn1 -> {
                textView?.setText(textView?.text.toString() + "1")
            }

            R.id.btn2 -> {
                textView?.setText(textView?.text.toString() + "2")
            }

            R.id.btn3 -> {
                textView?.setText(textView?.text.toString() + "3")
            }

            R.id.btn4 -> {
                textView?.setText(textView?.text.toString() + "4")
            }

            R.id.btn5 -> {
                textView?.setText(textView?.text.toString() + "5")
            }

            R.id.btn6 -> {
                textView?.setText(textView?.text.toString() + "6")
            }

            R.id.btn7 -> {
                textView?.setText(textView?.text.toString() + "7")
            }

            R.id.btn8 -> {
                textView?.setText(textView?.text.toString() + "8")
            }

            R.id.btn9 -> {
                textView?.setText(textView?.text.toString() + "9")
            }

            R.id.btn0 -> {
                textView?.setText(textView?.text.toString() + "0")
            }

            R.id.btnPunto -> {
                textView?.setText(textView?.text.toString() + ".")
            }

            R.id.btnSum -> {
                valorAnterior = textView?.text.toString()
                textView?.text = ""
                operador = "+"
            }

            R.id.btnRes -> {
                valorAnterior = textView?.text.toString()
                textView?.setText("")
                operador = "-"
            }

            R.id.btnMult -> {
                valorAnterior = textView?.text.toString()
                textView?.setText("")
                operador = "*"
            }

            R.id.btnDiv -> {
                valorAnterior = textView?.text.toString()
                textView?.setText("")
                operador = "/"
            }

            R.id.btnIgual -> {
                when (operador) {
                    "+" -> {
                        resultado = valorAnterior?.toFloat()!! + textView?.text.toString().toFloat()
                        textView?.setText(resultado.toString());
                    }

                    "-" -> {
                        resultado = valorAnterior?.toFloat()!! - textView?.text.toString().toFloat()
                        textView?.setText(resultado.toString());
                    }

                    "*" -> {
                        resultado = valorAnterior?.toFloat()!! * textView?.text.toString().toFloat()
                        textView?.setText(resultado.toString());
                    }

                    "/" -> {
                        resultado = valorAnterior?.toFloat()!! / textView?.text.toString().toFloat()
                        textView?.setText(resultado.toString());
                    }
                }
            }

            R.id.btnDel -> {
                var cadena = textView?.text.toString()
                if ((cadena != null) && (!cadena.equals(""))) {
                    cadena = cadena.substring(0, cadena.length - 1)
                    textView?.setText(cadena)
                }
            }
        }
    }
}