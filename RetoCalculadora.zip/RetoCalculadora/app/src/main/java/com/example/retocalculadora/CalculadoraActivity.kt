package com.example.retocalculadora

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.regex.Pattern

class CalculadoraActivity : AppCompatActivity() {
    private lateinit var screen: TextView
    private var display = ""
    private var opActual = ""
    private var resultado = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora)
        screen = findViewById(R.id.textView)
        screen.text = display
    }

    private fun updateScreen() {
        screen.text = display
    }

    fun onClickNumber(v: View) {
        if (resultado != "") {
            clear()
            updateScreen()
        }
        val b = v as Button
        display += b.text
        updateScreen()
    }

    private fun isOperator(op: Char): Boolean {
        return when (op) {
            '+', '-', 'x', '÷' -> true
            else -> false
        }
    }

    fun onClickOperator(v: View) {
        if (display == "") return

        val b = v as Button

        if (resultado != "") {
            val d = resultado
            clear()
            display = d
        }

        if (opActual != "") {
            Log.d("Calculadora", "" + display[display.length - 1])

            if (isOperator(display[display.length - 1])) {
                display = display.replace(display[display.length - 1], b.text[0])
                updateScreen()
                return
            } else {
                getResult()
                display = resultado
                resultado = ""
            }
            opActual = b.text.toString()
        }
        display += b.text
        opActual = b.text.toString()
        updateScreen()
    }

    private fun clear() {
        display = ""
        opActual = ""
        resultado = ""
    }

    private fun operate(a: String, b: String, op: String): Double {
        return when (op) {
            "+" -> a.toDouble() + b.toDouble()
            "-" -> a.toDouble() - b.toDouble()
            "x" -> a.toDouble() * b.toDouble()
            "÷" -> try {
                a.toDouble() / b.toDouble()
            } catch (e: Exception) {
                Log.d("Calculadora", e.message ?: "")
                Double.NaN
            }
            else -> Double.NaN
        }
    }

    private fun getResult(): Boolean {
        if (opActual == "") return false
        val operation = display.split(Pattern.quote(opActual))
        if (operation.size < 2) return false
        resultado = operate(operation[0], operation[1], opActual).toString()
        return true
    }
}