package com.example.retolayoutinflater

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Image2Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootView2 = LayoutInflater.from(this).inflate(R.layout.activity_image2, null)
        val linearLayout2: LinearLayout = rootView2.findViewById(R.id.linearLayoutContainer2)

        val nuevoTextView2 = TextView(this)
        nuevoTextView2.text = "¡Saludos! Yo soy una canguro hembra, y este es mi pequeño bebé. Pulsa sobre mí si deseas ver más animales de Australia."

        val canguro = ImageView(this)

        val editText2 = EditText(this)
        canguro.setImageResource(R.drawable.canguro)

        // Abre la siguiente pantalla al pulsar sobre la imagen del canguro:
        canguro.setOnClickListener {
            abrirImage3Activity()
        }

        linearLayout2.addView(nuevoTextView2)
        linearLayout2.addView(canguro)

        setContentView(rootView2)
    }

    private fun abrirImage3Activity() {
        val intent2 = Intent(this@Image2Activity, Image3Activity::class.java)
        startActivity(intent2)
    }
}