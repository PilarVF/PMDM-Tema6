package com.example.retolayoutinflater

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Image1Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootView1 = LayoutInflater.from(this).inflate(R.layout.activity_image1, null)
        val linearLayout1: LinearLayout = rootView1.findViewById(R.id.linearLayoutContainer1)

        val nuevoTextView1 = TextView(this)
        nuevoTextView1.text = "¡Hola! Soy un koala. ¿A que soy una monada? Pulsa sobre mí para pasar a la siguiente imagen."

        val koala = ImageView(this)

        val editText = EditText(this)
        koala.setImageResource(R.drawable.koala)

        // Abre la siguiente pantalla al pulsar sobre la imagen del koala:
        koala.setOnClickListener {
            abrirImage2Activity()
        }

        linearLayout1.addView(nuevoTextView1)
        linearLayout1.addView(koala)

        setContentView(rootView1)
    }

    private fun abrirImage2Activity() {
        val intent1 = Intent(this@Image1Activity, Image2Activity::class.java)
        startActivity(intent1)
    }
}