package com.example.retolayoutinflater

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Image3Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootView3 = LayoutInflater.from(this).inflate(R.layout.activity_image3, null)
        val linearLayout3: LinearLayout = rootView3.findViewById(R.id.linearLayoutContainer3)

        val nuevoTextView3 = TextView(this)
        nuevoTextView3.text = "¡Muy buenas! Yo soy un wombat, y he salido de mi madriguera para saludarte. Pulsa sobre mí para conocer a nuestro último amiguito."

        val wombat = ImageView(this)

        val editText3 = EditText(this)
        wombat.setImageResource(R.drawable.wombat)

        // Abre la siguiente pantalla al pulsar sobre la imagen del wombat:
        wombat.setOnClickListener {
            abrirImage3Activity()
        }

        linearLayout3.addView(nuevoTextView3)
        linearLayout3.addView(wombat)

        setContentView(rootView3)
    }

    private fun abrirImage3Activity() {
        val intent3 = Intent(this@Image3Activity, Image4Activity::class.java)
        startActivity(intent3)
    }
}