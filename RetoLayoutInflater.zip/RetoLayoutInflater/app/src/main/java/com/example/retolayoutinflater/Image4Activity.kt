package com.example.retolayoutinflater

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Image4Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootView4 = LayoutInflater.from(this).inflate(R.layout.activity_image4, null)
        val linearLayout4: LinearLayout = rootView4.findViewById(R.id.linearLayoutContainer4)

        val nuevoTextView4 = TextView(this)
        nuevoTextView4.text = "Y aquí nos despedimos... Soy el demonio de Tasmania, aunque tengo cara de no haber roto un plato. Mis amigos y yo esperamos haberte sacado una sonrisa. ¡Hasta la póxima!"

        val demonio = ImageView(this)

        val editText4 = EditText(this)
        demonio.setImageResource(R.drawable.demonio)

        linearLayout4.addView(nuevoTextView4)
        linearLayout4.addView(demonio)

        setContentView(rootView4)
    }
}