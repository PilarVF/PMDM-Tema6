package com.example.retolayoutinflater

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootView = LayoutInflater.from(this).inflate(R.layout.activity_main, null)
        setContentView(rootView)

        val btnGoToImages: AppCompatButton = findViewById(R.id.btnGoToImages)

        btnGoToImages.setOnClickListener {
            val intent = Intent(this@MainActivity, Image1Activity::class.java)
            startActivity(intent)
        }
    }
}